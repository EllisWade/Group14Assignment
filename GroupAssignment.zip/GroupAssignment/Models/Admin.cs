﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace GroupAssignment.Models
{
    public class Admin
    {
        public int Id { get; set; }

        public string AdminID { get; set; }
        [Display(Name = "Username")]
        public string AdminName { get; set; }
        [Display(Name = "Email")]
        public string AdminEmail { get; set; }
        [Display(Name = "Password")]
        public string AdminPass { get; set; }
    }
}
